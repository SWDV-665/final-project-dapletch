class ZipCode {

  zipCode: string;
  country: string;
  countryAbbreviation: string;
  places: Places[];

  constructor() {
  }

}
