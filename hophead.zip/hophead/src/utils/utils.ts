interface String {
  format(...replacements: string[]): string;
}

// @ts-ignore
if (!String.prototype.format) {
  // @ts-ignore
  String.prototype.format = function () {
    let args = arguments;
    return this.replace(/{(\d+)}/g, function (match, number) {
      return typeof args[number] != 'undefined' ? args[number] : match;
    });
  };
}

export class Utils {

  private static ZIP_CODE_REGEX = /^[0-9]{5}(?:-[0-9]{4})?$/;
  private static NO_LOCATIONS_FOUND = "No locations Found";

  public static isZipCode(zipCode: string) {
    if (zipCode != null) {
      if (zipCode.length > 0) {
        return this.ZIP_CODE_REGEX.test(zipCode);
      }
    }
    return false;
  }

  public static isBreweryValid(brewery: object) {
    // @ts-ignore
    return brewery.id !== 0 && brewery.id !== null && brewery.name !== this.NO_LOCATIONS_FOUND && brewery.name !== null && brewery.name !== "";
  }
}
