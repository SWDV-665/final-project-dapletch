import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {BeermappingConstants} from "../../constants/beermapping.constants";
import {Observable} from "rxjs";

/*
  Generated class for the BeermappingProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class BeermappingProvider {

  breweries = [];
  BEER_MAPPING_KEY = "7b86a9807f95c57de6ae1098616d04b2";

  constructor(public http: HttpClient) {
  }

  addBrewery(brewery: object): void {
    if (brewery) {
      if (!this.breweryExists(brewery)) {
        this.breweries.push(brewery);
      }
    }
  }

  breweryExists(brewery: object): boolean {
    return this.breweries.some(function (el) {
      // @ts-ignore
      return el.id === brewery.id;
    });
  }

  getBreweries(): Array<any> {
    return this.breweries;
  }

  clearBreweries(): void {
    this.breweries.length = 0;
  }

  /**
   * Example response:
   * [
   {
    "id": 19083,
    "name": "Four Quarters Brewing",
    "status": "Brewery",
    "reviewlink": "https://beermapping.com/location/19083",
    "proxylink": "http://beermapping.com/maps/proxymaps.php?locid=19083&amp;d=5",
    "blogmap": "http://beermapping.com/maps/blogproxy.php?locid=19083&amp;d=1&amp;type=norm",
    "street": "150 Canal St.",
    "city": "Winooski",
    "state": "VT",
    "zip": "05404",
    "country": "United States",
    "phone": "",
    "url": "fourquartersbrewing.+com",
    "overall": "0",
    "imagecount": "0"
  }
   ]
   * @param piece
   */
  public findBreweryByPiece(piece: string): Observable<any> {
    if (piece != null) {
      try {
        // @ts-ignore
        let endpoint = BeermappingConstants.LOQUERY.format(
          this.BEER_MAPPING_KEY,
          encodeURIComponent(piece.toLowerCase())
        );
        return this.http.get(endpoint);
      } catch (e) {
        console.error("An error occurred while finding brewery by piece: " + e.message);
      }
    }
  }

  /**
   * Example of response:
   * [
   {
    "id": 4096,
    "name": "Vermont Homebrew Supply",
    "status": "Homebrew",
    "reviewlink": "https://beermapping.com/location/4096",
    "proxylink": "http://beermapping.com/maps/proxymaps.php?locid=4096&amp;d=5",
    "blogmap": "http://beermapping.com/maps/blogproxy.php?locid=4096&amp;d=1&amp;type=norm",
    "street": "147 East Allen Street",
    "city": "Winooski",
    "state": "VT",
    "zip": "05404",
    "country": "United States",
    "phone": "(802) 655-2070",
    "url": "",
    "overall": "0",
    "imagecount": "0"
  },
   {
    "id": 19083,
    "name": "Four Quarters Brewing",
    "status": "Brewery",
    "reviewlink": "https://beermapping.com/location/19083",
    "proxylink": "http://beermapping.com/maps/proxymaps.php?locid=19083&amp;d=5",
    "blogmap": "http://beermapping.com/maps/blogproxy.php?locid=19083&amp;d=1&amp;type=norm",
    "street": "150 Canal St.",
    "city": "Winooski",
    "state": "VT",
    "zip": "05404",
    "country": "United States",
    "phone": "",
    "url": "fourquartersbrewing. com",
    "overall": "0",
    "imagecount": "0"
  }
   ]
   */
  findBreweriesByCity(city: string, stateCode: string) {
    if (city != null && stateCode != null) {
      try {
        // construct the url
        // @ts-ignore
        let endpoint = BeermappingConstants.LOCCITY.format(
          this.BEER_MAPPING_KEY,
          encodeURIComponent(city.toLowerCase()),
          encodeURIComponent(stateCode.toLowerCase())
        );

        return this.http.get(endpoint)

      } catch (e) {
        console.error("An error occurred while finding breweries: " + e.message);
      }
    }
  }

  public isBreweryResultValid(breweries: object[]) {

  }

  public formatBreweryUrl(url: string) {

  }

  public getBreweryMapById(id: string) {

  }

  public isBreweryMapValid(map: object) {

  }

  public getBreweryImageById(id: string) {

  }

  public isBreweryImageValid(image: object[]) {

  }
}
