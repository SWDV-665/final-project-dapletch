import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Utils} from "../../utils/utils";
import {ZipcodeConstants} from "../../constants/zipcode.constants";

/*
  Generated class for the ZipcodeProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ZipcodeProvider {

  constructor(public http: HttpClient) {
  }

  findStateByZipCode(zipCode: string) {
    if (Utils.isZipCode(zipCode)) {
      try {
        // @ts-ignore
        return this.http.get(ZipcodeConstants.ZIP_CODE.format("us", zipCode));
      } catch (e) {
        console.error("An error occurred while finding the zipCode: " + e.message);
      }
    }
  }

}
