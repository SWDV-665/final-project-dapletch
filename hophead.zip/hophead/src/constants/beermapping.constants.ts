/**
 * Class BeerMappingConstants
 * Used as the reference point for the API endpoints for the BeerMapping API
 * https://beermapping.com/api/reference/
 *
 * NOTE: the default return type for API queries is xml. If you want json returned instead,
 * simply add &s=json to the end of any of these queries.
 */
export class BeermappingConstants {

  // use string formatting to populate the API key from the configuration, and finally the name of the brewery
  public static readonly LOQUERY = "http://beermapping.com/webservice/locquery/{0}/{1}&s=json";

  public static readonly LOCCITY = "http://beermapping.com/webservice/loccity/{0}/{1},{2}&s=json";

  public static readonly LOCMAP = "http://beermapping.com/webservice/locmap/%s/%s&s=json";

  public static readonly LOCIMAGE = "http://beermapping.com/webservice/locimage/%s/%s&s=json";

}
