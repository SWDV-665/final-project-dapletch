class LocCity {
  /***
   * Populated by the the Loccity endpoint provided by Beermapping.com:
   * Reference to documentation: https://beermapping.com/api/reference/
    */
  public id: number;
  public name: string;
  public status: string;
  public reviewLink: string;
  public proxyLink: string;
  public blogMap: string;
  public street: string;
  public city: string;
  public state: string;
  public zip: string;
  public country: string;
  public phone: string;
  public url: string;
  public overall: number;
  public imageCount: number;

  constructor() {
  }
}
