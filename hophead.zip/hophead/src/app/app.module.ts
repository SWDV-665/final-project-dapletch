import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ZipcodeProvider } from '../providers/zipcode/zipcode';
import { BeermappingProvider } from '../providers/beermapping/beermapping';
import { GeolocationProvider } from '../providers/geolocation/geolocation';
import { NominatimProvider } from '../providers/nominatim/nominatim';
import { AutocompleteProvider } from '../providers/autocomplete/autocomplete';
import { SearchBreweriesProvider } from '../providers/search-breweries/search-breweries';
import {HttpClientModule} from '@angular/common/http';
import {SocialSharing} from '@ionic-native/social-sharing/ngx';

@NgModule({
  declarations: [
    MyApp,
    HomePage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpClientModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ZipcodeProvider,
    BeermappingProvider,
    GeolocationProvider,
    NominatimProvider,
    AutocompleteProvider,
    SearchBreweriesProvider,
    SocialSharing
  ]
})
export class AppModule {}
