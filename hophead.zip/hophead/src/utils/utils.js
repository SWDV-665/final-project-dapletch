if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var Utils = /** @class */ (function () {
    function Utils() {
    }
    Utils.isZipCode = function (zipCode) {
        if (zipCode != null) {
            if (zipCode.length > 0) {
                return this.ZIP_CODE_REGEX.test(zipCode);
            }
        }
        return false;
    };
    Utils.ZIP_CODE_REGEX = /^[0-9]{5}(?:-[0-9]{4})?$/;
    return Utils;
}());
//# sourceMappingURL=utils.js.map