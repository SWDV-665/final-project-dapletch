var NominatimConstants = /** @class */ (function () {
    function NominatimConstants() {
    }
    // https://nominatim.org/release-docs/develop/api/Search/
    // example: https://nominatim.openstreetmap.org/search/?street=160%20Flynn%20Avenue&city=Burlington&state=VT&country=us&postalCode=5401&format=json
    NominatimConstants.SEARCH = "https://nominatim.openstreetmap.org/search/?street=%s&city=%s&state=%s&country=%s&postalCode=%s&format=json";
    return NominatimConstants;
}());
//# sourceMappingURL=nominatim.constants.js.map