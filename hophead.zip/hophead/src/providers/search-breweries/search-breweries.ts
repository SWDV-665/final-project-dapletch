import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';

/*
  Generated class for the SearchBreweriesProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SearchBreweriesProvider {

  constructor(public http: HttpClient) {
    console.log('Hello SearchBreweriesProvider Provider');
  }

  /*
  public autoCompleteBreweries(query: string) {
    let breweries = [];
    if (query != null || query != undefined) {
      if (Utils.isZipCode(query)) {
        // todo account for if condition
      } else {
        // todo account for else condition
      }
    }
    return breweries;
  }
   */

}
