import {Component} from '@angular/core';
import {NavController, ToastController} from 'ionic-angular';
import {ZipcodeProvider} from "../../providers/zipcode/zipcode";
import {BeermappingProvider} from "../../providers/beermapping/beermapping";
import {Utils} from "../../utils/utils";
import {SocialSharing} from "@ionic-native/social-sharing/ngx";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  public breweries: Array<any>;
  public hasSearchBeenCompleted: boolean = false;

  constructor(public navCtrl: NavController,
              public toastCtrl: ToastController,
              public zipCodeProvider: ZipcodeProvider,
              public beerMappingProvider: BeermappingProvider,
              public socialSharing: SocialSharing) {
  }

  // method that actually performs the search
  // finish search feature using following documentation:
  // https://jsmobiledev.com/article/searchbar-firebase
  async getBreweries(evt) {
    const query = evt.target.value;
    if (query != null && query) {
      // have to define beerMapping as it's own variable
      // so it can be called within the forEach loop
      let beerMapping = this.beerMappingProvider;
      if (this.hasSearchBeenCompleted && beerMapping.getBreweries().length > 0) {
        beerMapping.clearBreweries();
      }
      if (Utils.isZipCode(query)) {
        this.zipCodeProvider.findStateByZipCode(query).subscribe(zipCode =>
          zipCode["places"].forEach(function (item, index) {
            beerMapping.findBreweriesByCity(item["place name"], item["state abbreviation"]).subscribe(breweries =>
              // @ts-ignore, since breweries is really of type Array
              breweries.forEach(function (brewery, index) {
                if (Utils.isBreweryValid(brewery)) {
                  beerMapping.addBrewery(brewery)
                }
              })
            )
          })
        );
        this.hasSearchBeenCompleted = true;
      } else {
        this.hasSearchBeenCompleted = true;
        // assigning to breweries since it's the same data structure being returned as findBreweriesByCity method
        beerMapping.findBreweryByPiece(query.toLowerCase()).subscribe(breweries =>
          // @ts-ignore, since breweries is really of type Array
          breweries.forEach(function (brewery, index) {
            if (Utils.isBreweryValid(brewery)) {
              beerMapping.addBrewery(brewery)
            }
          })
        )
      }
      this.breweries = beerMapping.getBreweries();
    }
  }

  formatUrl(url: string) {
    if (url) {
      if (url.length > 0) {
        url = decodeURIComponent(
          url = !(url.includes("http://www.") || url.includes("https://www.")) ?
            `https://www.${url}`.replace(" ", "") : url
        );
      }
    }
    return url;
  }

  // will error when rendered via web browser since this is a native plugin
  async shareBrewery(brewery: object) {
    // @ts-ignore
    console.log("Sharing Brewery - ", brewery.id);
    const toast = await this.toastCtrl.create({
      // @ts-ignore
      message: 'Sharing Brewery - ' + brewery.name + " ...",
      duration: 3000
    });

    toast.present();

    // @ts-ignore
    let message = "Brewery Name: " + brewery.name;
    let subject = "Shared via Hophead App";

    this.socialSharing.share(message, subject).then(() => {
      // Sharing via email is possible
      console.log("Shared successfully!");
    }).catch((error) => {
      console.error("Error while sharing ", error);
    });

  }
}
