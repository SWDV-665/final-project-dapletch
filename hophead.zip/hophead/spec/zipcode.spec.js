describe('Zip Code Service', function () {
    it('should correctly add numbers', function () {
        expect(1 + 1).toBe(2);
    });
});
//# sourceMappingURL=zipcode.spec.js.map