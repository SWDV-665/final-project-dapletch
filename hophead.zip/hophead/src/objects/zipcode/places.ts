class Places {

  placeName: string;
  longitude: number;
  state: string;
  stateAbbreviation: string;
  latitude: number;

  constructor() {
  }

}
