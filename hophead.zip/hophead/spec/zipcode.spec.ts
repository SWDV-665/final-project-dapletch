describe('Zip Code Service', () => {

  it('should correctly add numbers', () => {

    expect(1 + 1).toBe(2);

  });

});
