import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the NominatimProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class NominatimProvider {

  constructor(public http: HttpClient) {
    console.log('Hello NominatimProvider Provider');
  }

  // TODO apply programming logic to create methods for API calls like so:
  //  https://rapidapi.com/blog/how-to-use-an-api-with-typescript/
  public searchByAddress(street: string, city: string, state: string, country: string, postalCode: string) {

  }

}
